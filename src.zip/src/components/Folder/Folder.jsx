import React from 'react';
import './Folder.css';
const Asset = require('../../images/folder_red.png');

const Folder = () => (
        <div id="folderContainer">
            <img src='/static/media/folder_red.90acdd63.png' alt="icon" />
        </div>
    )

export default Folder;